@echo off
if exist "%~dp0AirMic.Windows.exe" (
    start "" "%~dp0AirMic.Windows.exe" --systray
) else (
    start "" "%~dp0AirMic.exe" --systray
)
