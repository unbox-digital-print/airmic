@echo off
if exist "%~dp0AirMic.Windows.exe" (
    start "" "%~dp0AirMic.Windows.exe"
) else (
    start "" "%~dp0AirMic.exe"
)
